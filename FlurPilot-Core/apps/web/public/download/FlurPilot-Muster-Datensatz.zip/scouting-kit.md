# Hidden-Land Scouting Kit 2026

> Strategien zur systematischen Identifikation von Aufstellungsbeschlüssen in kommunalen Ratsinformationssystemen

---

## Über dieses Kit

Dieses Dokument gibt Ihnen einen strukturierten Ansatz, um **Aufstellungsbeschlüsse für Sondergebiete (Photovoltaik)** in den öffentlichen Sitzungsprotokollen deutscher Kommunen zu finden – bevor die Konkurrenz davon erfährt.

**Inhalt:**
1. Einführung: Das "Seite 47" Problem
2. Die Keyword-Matrix (50+ Suchbegriffe)
3. Der Bewertungs-Bogen
4. Praxisbeispiel mit Muster-Datensatz
5. Nächste Schritte

---

## 1. Das "Seite 47" Problem

### Die Situation
- Deutschland hat **~11.000 Kommunen** mit eigenständigen Ratsinformationssystemen (RIS)
- Relevante Beschlüsse verstecken sich in **PDF-Anhängen** von Sitzungsprotokollen
- Zwischen Aufstellungsbeschluss und Pressebekanntmachung liegen oft **3-6 Monate**
- Wer erst durch die Zeitung erfährt, findet meist bereits verpachtete Flächen vor

### Warum "Seite 47"?
Der typische Aufstellungsbeschluss findet sich nicht auf Seite 1, sondern:
- Als Tagesordnungspunkt 12 von 15
- Als Anlage 3 zum Protokoll
- In einem Beschlussvorschlag des Bauamts

### Die Lösung
Systematische Keyword-Suche in den **öffentlich indexierten PDFs** via Google Site Search.

---

## 2. Die Keyword-Matrix

### Primäre Suchbegriffe (Höchste Relevanz)

| Kategorie | Keywords |
|-----------|----------|
| **Beschluss-Typen** | Aufstellungsbeschluss, Einleitungsbeschluss, Satzungsbeschluss |
| **Planungsarten** | Bebauungsplan, B-Plan, Flächennutzungsplan, FNP, Bauleitplanung |
| **Sondergebiete** | Sondergebiet, SO PV, SO Photovoltaik, Sondergebiet Freiflächen-PV |
| **Paragraphen** | §35 BauGB, §2 BauGB, §5 BauGB, Außenbereichsfläche |

### Sekundäre Suchbegriffe (Kontextuelle Relevanz)

| Kategorie | Keywords |
|-----------|----------|
| **Flächenbezeichnungen** | Flurstück, Flur, Gemarkung, Ackerland, Grünland |
| **Technische Begriffe** | Freiflächen-Photovoltaik, Solarpark, PV-Freiflächenanlage, Agri-PV |
| **Verfahrensschritte** | Öffentliche Auslegung, Trägerbeteiligung, frühzeitige Beteiligung |
| **Kriterienkatalog** | Standortkonzept, Eignungsflächen, Potenzialflächen |

### Ausschlussbegriffe (Vermeiden)

Diese Begriffe deuten auf **nicht relevante** oder **bereits gescheiterte** Vorhaben hin:

- "abgelehnt"
- "zurückgestellt"
- "vertagt auf unbestimmte Zeit"
- "Antrag zurückgezogen"
- "nicht beschlossen"

---

## 3. Der Bewertungs-Bogen

Wenn Sie einen potenziellen Treffer gefunden haben, bewerten Sie ihn anhand dieser Checkliste:

### Relevanz-Check ✓

| Kriterium | Ja | Nein | Punkte |
|-----------|:--:|:----:|:------:|
| Ist es ein **Aufstellungsbeschluss** (nicht nur Diskussion)? | ☐ | ☐ | +3 |
| Wird "Sondergebiet PV" oder "§35 BauGB" explizit genannt? | ☐ | ☐ | +2 |
| Sind **Flurstücknummern** oder Gemarkungen angegeben? | ☐ | ☐ | +2 |
| Handelt es sich um eine **Gemeinderatssitzung** (nicht Ausschuss)? | ☐ | ☐ | +1 |
| Ist das Protokoll aus den **letzten 6 Monaten**? | ☐ | ☐ | +1 |

### Risiko-Check ⚠️

| Risikofaktor | Ja | Nein | Punkte |
|--------------|:--:|:----:|:------:|
| Gibt es bereits **öffentliche Bekanntmachungen** in der Presse? | ☐ | ☐ | -3 |
| Wurde das Vorhaben **kontrovers diskutiert** (Bürgerprotest)? | ☐ | ☐ | -2 |
| Handelt es sich um **privilegierte Flächen** (FFH, Naturschutz)? | ☐ | ☐ | -2 |

### Bewertung

| Score | Einstufung |
|-------|------------|
| 7-9 | **🟢 Hohe Priorität** – Sofort Grundbucheigentümer recherchieren |
| 4-6 | **🟡 Mittlere Priorität** – Weitere Informationen einholen |
| 0-3 | **🔴 Niedrige Priorität** – Auf Watchlist setzen |
| <0 | **⚫ Ausschluss** – Nicht weiterverfolgen |

---

## 4. Praxisbeispiel

### Suchquery

```
site:niederkruechten.de filetype:pdf "Aufstellungsbeschluss" "Sondergebiet"
```

### Fundstelle (Auszug)

> **TOP 5: Antrag auf Einleitung eines Bebauungsplanverfahrens**
> 
> Der Rat der Gemeinde Niederkrüchten beschließt die Aufstellung des Bebauungsplans Nr. 127 "Sondergebiet Freiflächen-Photovoltaikanlage Overhetfeld".
> 
> Betroffen sind die Flurstücke 24, 25 und 26 der Flur 9, Gemarkung Overhetfeld.

### Extrahierte Daten

| Feld | Wert |
|------|------|
| Kommune | Niederkrüchten |
| Bundesland | Nordrhein-Westfalen |
| B-Plan Nr. | 127 |
| Bezeichnung | Sondergebiet Freiflächen-PV Overhetfeld |
| Gemarkung | Overhetfeld |
| Flur | 9 |
| Flurstücke | 24, 25, 26 |
| Score | **8/9** (Hohe Priorität) |

### Geo-Daten (KML)

Siehe beiliegende Datei `muster-datensatz.kml` für die Polygon-Darstellung in Google Earth Pro.

---

## 5. Nächste Schritte

### Manueller Workflow

1. **Wöchentliche Suche** in Ihren Ziel-Landkreisen durchführen
2. Treffer mit dem **Bewertungs-Bogen** prüfen
3. Bei Score ≥7: **Grundbucheigentümer** über Katasteramt ermitteln
4. **Erstkontakt** mit standardisiertem Anschreiben

### Automatisierung mit FlurPilot

Das manuelle Vorgehen funktioniert – aber es skaliert nicht. 

**FlurPilot Core** automatisiert diesen Prozess:
- Bundesweite Überwachung aller RIS-Portale
- KI-gestützte Extraktion von Flurnummern
- Validierung gegen Katasterdaten
- Verifizierte Geo-Leads direkt in Ihr Postfach

**Interesse?** Antworten Sie auf die E-Mail, mit der Sie dieses Kit erhalten haben, um eine persönliche Demo zu vereinbaren.

---

## Rechtlicher Hinweis

Alle in diesem Dokument beschriebenen Methoden nutzen ausschließlich **öffentlich zugängliche Informationen**. Die Recherche in Ratsinformationssystemen ist legal und entspricht dem Open-Data-Prinzip.

Dieses Dokument dient ausschließlich zu Informationszwecken. Es stellt keine Rechtsberatung dar.

---

**© 2026 FlurPilot | Stephan Ochmann**

📧 info@flurpilot.de  
🌐 flurpilot.de
